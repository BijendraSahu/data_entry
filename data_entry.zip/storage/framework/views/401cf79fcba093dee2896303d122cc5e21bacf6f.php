<?php $__env->startSection('title','List of Users'); ?>

<?php $__env->startSection('content'); ?>
    
    
    
    
    
    
    
    
    <div class="row box_containner">
        <div class="col-sm-12 col-md-12 col-xs-12">
            <div class="dash_boxcontainner white_boxlist">
                <div class="upper_basic_heading"><span class="white_dash_head_txt">
                         List of All Users
                        
                        
                        <a href="#" class="btn btn-default btnSet add-user pull-right">
        <span class="fa fa-plus"></span>&nbsp;Create New User</a>
                      </span>
                    <table id="example" class="table table-bordered dataTable table-striped" cellspacing="0"
                           width="100%">
                        <thead>
                        <tr class="bg-info">
                            <th class="hidden">Id</th>
                            <th class="options">Options</th>
                            <th>Profile</th>
                            <th>User Id</th>
                            <th>Name</th>
                            <th>Contact</th>
                            
                            <th>Username</th>
                            <th>Role</th>
                            <th>Work Count</th>
                            <th>Active Status</th>
                            <th>Joining Date</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if(count($user_masters)>0): ?>
                            <?php $__currentLoopData = $user_masters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_master): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $work_count = \App\SchoolData::where(['IS_WORK_DONE' => 1,'WORK_DONE_BY' =>$user_master->id])->count();
                                ?>
                                <tr>
                                    <td class="hidden"><?php echo e($user_master->id); ?></td>
                                    <td id="<?php echo e($user_master->id); ?>">
                                        <a href="#" id="<?php echo e($user_master->id); ?>" onclick="edit_user(this)"
                                           class="btn btn-sm btn-default edit-user_"
                                           title="Edit User" data-toggle="tooltip" data-placement="top">
                                            <span class="fa fa-pencil"></span></a>
                                        <?php if($user_master->is_active == 1): ?>
                                            <a href="#" id="<?php echo e($user_master->id); ?>" onclick="inactive_user(this)"
                                               class="btn btn-sm btn-danger"
                                               title="Mark as inactive" data-toggle="tooltip"
                                               data-placement="top">
                                                <span class="mdi mdi-delete"></span></a>
                                        <?php else: ?>
                                            <a href="#" id="<?php echo e($user_master->id); ?>" onclick="active_user(this)"
                                               class="btn btn-sm btn-primary"
                                               title="Mark as active" data-toggle="tooltip" data-placement="top">
                                                <span class="mdi mdi-check"></span></a>

                                        <?php endif; ?>
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        

                                    </td>
                                    <td>
                                        <div class="post_imgblock_admin">
                                            <?php if(isset($user_master->profile_img)): ?>
                                                <img style="height: 100%; width: 100%"
                                                     src="<?php echo e(url('').'/'.$user_master->profile_img); ?>"/>
                                            <?php else: ?>
                                                <img style="height: 100%; width: 100%"
                                                     src="<?php echo e(url('assets/images/Male_default.png')); ?>"/>
                                            <?php endif; ?>

                                        </div>
                                    </td>
                                    <td><?php echo e($user_master->id); ?></td>
                                    <td><?php echo e($user_master->name); ?></td>
                                    <td><?php echo e($user_master->contact); ?></td>
                                    <td><?php echo e($user_master->username); ?></td>
                                    <td><?php echo e($user_master->role); ?></td>
                                    <td><?php echo e($work_count); ?></td>
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    

                                    <td>
                                        <?php if($user_master->is_active == 1): ?>
                                            <p class="bg-success">Active</p>
                                        <?php else: ?>
                                            <p class="bg-danger">InActive</p>

                                        <?php endif; ?>
                                    </td>
                                    <td> <?php echo e(date_format(date_create($user_master->created_time), "d-M-Y h:i A")); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script>
        function inactive_user(dis) {
            var id = $(dis).attr('id');
            $('#myModal').modal('show');
            $('#mybody').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
            $('#modal_title').html('Confirm Inactivation');
            $('#mybody').html('<h5>Are you sure want to Inactivate/unpaid this user<h5/>');
            $('#modalBtn').removeClass('hidden');
            $('#modalBtn').html('<a class="btn btn-sm btn-danger" href="<?php echo e(url('user_master')); ?>/' + id +
                '/inactivate"><span class="glyphicon glyphicon-ok" aria-hidden="true"></span> Confirm</a>'
            );
        }

        function active_user(dis) {
            var id = $(dis).attr('id');
            $('#myModal').modal('show');
            $('#mybody').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
            $('#modal_title').html('Confirm Inactivation');
            $('#mybody').html('<h5>Are you sure want to activate this user<h5/>');
            $('#modalBtn').removeClass('hidden');
            $('#modalBtn').html('<a class="btn btn-sm btn-success" href="<?php echo e(url('user_master')); ?>/' + id +
                '/activate"><span class="glyphicon glyphicon-ok" aria-hidden="true"></span> Confirm</a>'
            );
        }

        function empty_user(dis) {
            var id = $(dis).attr('id');
            $('#myModal').modal('show');
            $('#mybody').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
            $('#modal_title').html('Confirm Inactivation');
            $('#mybody').html('<h5>Are you sure want to empty points for this user<h5/>');
            $('#modalBtn').removeClass('hidden');
            $('#modalBtn').html('<a class="btn btn-sm btn-danger" href="<?php echo e(url('user_master')); ?>/' + id +
                '/empty"><span class="glyphicon glyphicon-ok" aria-hidden="true"></span> Confirm</a>'
            );
        }

        function remind_user(dis) {
            var id = $(dis).attr('id');
            $('#myModal').modal('show');
            $('#mybody').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
            $('#modal_title').html('Confirm Inactivation');
            $('#mybody').html('<h5>Are you sure want to remind this user for payment<h5/>');
            $('#modalBtn').removeClass('hidden');
            $('#modalBtn').html('<a class="btn btn-sm btn-success" href="<?php echo e(url('user_master')); ?>/' + id +
                '/remind"><span class="glyphicon glyphicon-ok" aria-hidden="true"></span> Confirm</a>'
            );
        }
        $(".add-user").click(function () {
            $('#myModal').modal('show');
            $('#modal_title').html('Add New User');
            $('#mybody').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
            //alert(id);
            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url: "<?php echo e(url('user_master/create')); ?>",
                success: function (data) {
                    $('#mybody').html(data);
//            $('#modelBtn').visible(disabled);
                },
                error: function (xhr, status, error) {
                    $('#mybody').html(xhr.responseText);
                    //$('.modal-body').html("Technical Error Occured!");
                }
            });

        });
        
        
        
        

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        


        
        
        
        
        
        
        
        
        
        
        
        
        

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        function edit_user(dis) {
            $('#myModal').modal('show');
            $('#modal_title').html('Edit User');
            $('#mybody').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/images/loading.gif')); ?>"/>');
            var id = $(dis).attr('id');
            var editurl = '<?php echo e(url('/')); ?>' + "/user_master/" + id + "/edit";
            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url: editurl,
                data: '{"data":"' + id + '"}',
                success: function (data) {
                    $('#mybody').html(data);
                },
                error: function (xhr, status, error) {
                    $('#mybody').html(xhr.responseText);
                    //$('.modal-body').html("Technical Error Occured!");
                }
            });
        }


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>