<?php $__env->startSection('title','List of Advertisement'); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .ads_img {
            height: 100px;
            width: 100px;
        }
    </style>
    
    
    
    
    
    
    
    
    <div class="row box_containner">
        <div class="col-sm-12 col-md-12 col-xs-12">
            <div class="dash_boxcontainner white_boxlist">
                <div class="upper_basic_heading"><span class="white_dash_head_txt">
                         List of All Advertisement
                          <button onclick="add_ads()" class="btn btn-default pull-right"><i
                                      class="mdi mdi-plus"></i>Add</button>
                      </span>
                    <table id="example" class="table table-bordered dataTable table-striped" cellspacing="0"
                           width="100%">
                        <thead>
                        <tr class="bg-info">
                            <th class="hidden">Id</th>
                            <th class="options">Options</th>
                            <th>File Type</th>
                            <th>Content</th>
                            
                            <th>Visible Days</th>
                            <th>Visible Till</th>
                            <th>Active Status</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if(count($ads)>0): ?>
                            <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="hidden"><?php echo e($ad->id); ?></td>
                                    <td id="<?php echo e($ad->id); ?>">
                                        <a href="#" id="<?php echo e($ad->id); ?>" onclick="edit_ads(this)"
                                           class="btn btn-sm btn-default edit-user_"
                                           title="Edit Advertisement" data-toggle="tooltip" data-placement="top">
                                            <span class="fa fa-pencil"></span></a>
                                        <?php if($ad->is_active == 1): ?>
                                            <button type="button" onclick="inactive_ads(this)"
                                                    id="<?php echo e($ad->id); ?>"
                                                    class="btn btn-sm btn-danger btnDelete"
                                                    title="Inactivate Advertisement" data-toggle="tooltip"
                                                    data-placement="top"><span
                                                        class="fa fa-trash-o" aria-hidden="true"></span>
                                            </button>
                                        <?php else: ?>
                                            <button type="button" onclick="active_ads(this)"
                                                    id="<?php echo e($ad->id); ?>"
                                                    class="btn btn-sm btn-success btnActive"
                                                    title="Activate Advertisement" data-toggle="tooltip"
                                                    data-placement="top"><span
                                                        class="fa fa-align-center"
                                                        aria-hidden="true"></span></button>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($ad->file_type); ?></td>
                                    <td>
                                        <?php if($ad->file_type == 'text'): ?>
                                            <?php echo $ad->text; ?>

                                        <?php elseif($ad->file_type == 'video'): ?>
                                            <?php echo e($ad->file_path); ?>

                                        <?php else: ?>
                                            <img src="<?php echo e(url('').'/'.$ad->file_path); ?>" class="ads_img" alt="image">
                                        <?php endif; ?>

                                    </td>

                                    <td><?php echo e($ad->visible_days." Days"); ?></td>
                                    <td><?php echo e(date_format(date_create($ad->visible_till), "d-M-Y h:i A")); ?></td>
                                    <td><?php if($ad->is_active == 1): ?>
                                            <p class="bg-success">Active</p>
                                        <?php else: ?>
                                            <p class="bg-danger">Inactive</p>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <br/>
    <script>
        function inactive_ads(dis) {
            var id = $(dis).attr('id');
            $('#myModal').modal('show');
            $('#mybody').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/images/loading.gif')); ?>"/>');
            $('#modal_title').html('Confirm Inactivation');
            $('#mybody').html('<h5>Are you sure want to Inactivate this Advertisement<h5/>');
            $('#modalBtn').removeClass('hidden');
            $('#modalBtn').html('<a class="btn btn-sm btn-danger" href="<?php echo e(url('advertisement')); ?>/' + id +
                '/inactivate"><span class="glyphicon glyphicon-ok" aria-hidden="true"></span> Confirm</a>'
            );
        }

        function active_ads(dis) {
            var id = $(dis).attr('id');
            $('#myModal').modal('show');
            $('#mybody').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/img/loading.gif')); ?>"/>');
            $('#modal_title').html('Confirm Activation');
            $('#mybody').html('<h5>Are you sure want to activate this Advertisement<h5/>');
            $('#modalBtn').removeClass('hidden');
            $('#modalBtn').html('<a class="btn btn-sm btn-success" href="<?php echo e(url('advertisement')); ?>/' + id +
                '/activate"><span class="glyphicon glyphicon-ok" aria-hidden="true"></span> Confirm</a>'
            );
        }

        function edit_ads(dis) {
            $('#myModal').modal('show');
            $('#modal_title').html('Edit Advertisement');
            $('#mybody').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/images/loading.gif')); ?>"/>');
            var id = $(dis).attr('id');
            var editurl = '<?php echo e(url('/')); ?>' + "/advertisement/" + id + "/edit";
            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url: editurl,
                data: '{"data":"' + id + '"}',
                success: function (data) {
                    $('#mybody').html(data);
                },
                error: function (xhr, status, error) {
                    $('#mybody').html(xhr.responseText);
                    //$('.modal-body').html("Technical Error Occured!");
                }
            });
        }


        function add_ads() {
            $('#myModal').modal('show');
            $('#modal_title').html('Add New Advertisement');
            $('#mybody').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/images/loading.gif')); ?>"/>');
            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url: "<?php echo e(url('advertisement/create')); ?>",
                success: function (data) {
                    $('#mybody').html(data);
                },
                error: function (xhr, status, error) {
                    $('#mybody').html(xhr.responseText);
                }
            });
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>