<?php $__env->startSection('title','List of Gain Type Points'); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .ads_img {
            height: 200px;
            width: 200px;
        }
    </style>
    
    
    
    
    
    
    
    
    <div class="row box_containner">
        <div class="col-sm-12 col-md-12 col-xs-12">
            <div class="dash_boxcontainner white_boxlist">
                <div class="upper_basic_heading"><span class="white_dash_head_txt">
                         List of Gain Type Points
                      </span>
                    <table id="example" class="table table-bordered dataTable table-striped" cellspacing="0"
                           width="100%">
                        <thead>
                        <tr class="bg-info">
                            <th class="hidden">Id</th>
                            <th class="options">Options</th>
                            <th>Gain Type</th>
                            <th>Points</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if(count($gain_types)>0): ?>
                            <?php $__currentLoopData = $gain_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gain_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="hidden"><?php echo e($gain_type->id); ?></td>

                                    <td>  <a href="#" id="<?php echo e($gain_type->id); ?>" onclick="edit_gain_type(this)"
                                             class="btn btn-sm btn-default edit-user_"
                                             title="Edit Gain Type Points" data-toggle="tooltip" data-placement="top">
                                            <span class="fa fa-pencil"></span></a></td>
                                    <td><?php echo e($gain_type->gain_type); ?></td>
                                    <td><?php echo e($gain_type->points); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <br/>
    <script>
        function edit_gain_type(dis) {
            $('#myModal').modal('show');
            $('#modal_title').html('Edit Gain Type Points');
            $('#mybody').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/images/loading.gif')); ?>"/>');
            var id = $(dis).attr('id');
            var editurl = '<?php echo e(url('/')); ?>' + "/gain_type_points/" + id + "/edit";
            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url: editurl,
                data: '{"data":"' + id + '"}',
                success: function (data) {
                    $('#mybody').html(data);
                },
                error: function (xhr, status, error) {
                    $('#mybody').html(xhr.responseText);
                    //$('.modal-body').html("Technical Error Occured!");
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>