<script src="<?php echo e(url('assets/js/validation.js')); ?>"></script>

<?php echo Form::open(['url' => 'gain_type_points/'.$gain_types->id, 'class' => 'form-horizontal', 'id'=>'user_master', 'method'=>'post']); ?>

<div class="container-fluid">
    <div class="container-fluid">
        <div class="col-sm-12">
            <div class='form-group'>
                <?php echo Form::label('name', 'Gain Type *', ['class' => 'col-sm-2 control-label']); ?>

                <div class='col-sm-10'>
                    <select name="gain_type" disabled id="gain_type" class="form-control">
                        <option <?php echo e($gain_types->gain_type == 'img'?'selected':''); ?> value="img">Image</option>
                        <option <?php echo e($gain_types->gain_type == 'video'?'selected':''); ?> value="video">Video</option>
                        <option <?php echo e($gain_types->gain_type == 'text'?'selected':''); ?> value="text">Text</option>
                        <option <?php echo e($gain_types->gain_type == 'share'?'selected':''); ?> value="share">Share</option>
                        <option <?php echo e($gain_types->gain_type == 'referral'?'selected':''); ?> value="referral">Referral</option>
                        <option <?php echo e($gain_types->gain_type == 'activate'?'selected':''); ?> value="activate">Activate</option>
                    </select>
                </div>
            </div>
            <div class="form-group" id="getText">
                <?php echo Form::label('text', 'Points *', ['class' => 'col-sm-2 control-label']); ?>

                <div class='col-sm-10'>
                    <?php echo Form::text('points', $gain_types->points, ['class' => 'form-control input-sm', 'placeholder'=>'Enter Points','id'=>'Points']); ?>

                </div>
            </div>
            <div class='form-group'>
                <div class='col-sm-offset-2 col-sm-10'>
                    <?php echo Form::submit('Submit', ['class' => 'btn btn-sm btn-primary']); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php echo Form::close(); ?>

