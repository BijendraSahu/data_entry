<script src="<?php echo e(url('assets/js/validation.js')); ?>"></script>

<?php echo Form::open(['url' => 'assign_key/'.$key->id, 'class' => 'form-horizontal', 'id'=>'user_master', 'method'=>'post', 'files'=>true]); ?>

<div class="container-fluid">
    <div class="col-sm-12">


        <div class="form-group">
            <?php echo Form::label('role', 'Franchises *', ['class' => 'col-sm-2 control-label']); ?>

            <div class='col-sm-8'>
                <?php echo Form::select('franchise_id', $franchises, null,['class' => 'form-control requiredDD']); ?>

            </div>
        </div>
        <div class='form-group'>
            <?php echo Form::label('name', 'No of time uses *', ['class' => 'col-sm-2 control-label']); ?>

            <div class='col-sm-8'>
                <?php echo Form::text('no_of_uses', null, ['class' => 'form-control input-sm numberOnly required','placeholder'=>'Enter how many time uses of this key']); ?>

            </div>
        </div>
        <div class='form-group'>
            <div class='col-sm-offset-2 col-sm-8'>
                <?php echo Form::submit('Submit', ['class' => 'btn btn-sm btn-primary']); ?>

            </div>
        </div>

    </div>
</div>
<?php echo Form::close(); ?>

