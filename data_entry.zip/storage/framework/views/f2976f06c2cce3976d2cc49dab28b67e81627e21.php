<?php $__env->startSection('title','List of Redeem Requests'); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .ads_img {
            height: 200px;
            width: 200px;
        }
    </style>
    
    
    
    
    
    
    
    
    <div class="row box_containner">
        <div class="col-sm-12 col-md-12 col-xs-12">
            <div class="dash_boxcontainner white_boxlist">
                <div class="upper_basic_heading"><span class="white_dash_head_txt">
                         List of Redeem Requests
                      </span>
                    <table id="example" class="table table-bordered dataTable table-striped" cellspacing="0"
                           width="100%">
                        <thead>
                        <tr class="bg-info">
                            <th class="hidden">Id</th>
                            <th class="options">Options</th>
                            <th>Name</th>
                            <th>Contact</th>
                            <th>Paytm Contact</th>
                            <th>Points Request</th>
                            <th>Amount</th>
                            <th>Payable Amount</th>
                            <th>Status</th>
                            <th>Reject Reason</th>
                            <th>Approval Date</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if(count($redeem_requests)>0): ?>
                            <?php $__currentLoopData = $redeem_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $redeem_request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $user_bank = \App\UserBankDetails::where(['user_id'=>$redeem_request->user_id])->first();

                                ?>
                                <?php if(isset($user_bank->aadhar_pan)): ?>
                                    <?php $pay_amt = $redeem_request->amount-$redeem_request->amount*10/100;
                                    $tds_percent = 10;
                                    ?>
                                <?php else: ?>
                                    <?php $pay_amt = $redeem_request->amount-$redeem_request->amount*20/100;
                                    $tds_percent = 20;
                                    ?>
                                <?php endif; ?>
                                <tr>
                                    <td class="hidden"><?php echo e($redeem_request->id); ?></td>
                                    <td id="<?php echo e($redeem_request->id); ?>">
                                        <?php if($redeem_request->status == 'pending'): ?>
                                            <button type="button" onclick="reject(this)"
                                                    id="<?php echo e($redeem_request->id); ?>"
                                                    class="btn btn-sm btn-danger btnDelete"
                                                    title="Reject Request" data-toggle="tooltip"
                                                    data-placement="top"><span
                                                        class="fa fa-trash-o" aria-hidden="true"></span>
                                            </button>
                                            <button type="button" onclick="approved(this)"
                                                    id="<?php echo e($redeem_request->id); ?>"
                                                    class="btn btn-sm btn-success btnActive"
                                                    title="Approve Request" data-toggle="tooltip"
                                                    data-placement="top"><span
                                                        class="fa fa-check"
                                                        aria-hidden="true"></span></button>

                                        <?php else: ?>
                                            <?php echo e('N/A'); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(isset($redeem_request->user->name)?$redeem_request->user->name:"-"); ?></td>
                                    <td><?php echo e(isset($redeem_request->user->contact)?$redeem_request->user->contact:''); ?></td>
                                    <td><?php echo e(isset($redeem_request->user->paytm_contact)?$redeem_request->user->paytm_contact:''); ?></td>
                                    <td><?php echo e($redeem_request->point); ?></td>
                                    <td><?php echo e("Rs. ".$redeem_request->amount); ?></td>
                                    <td><?php echo e("Rs. ".$pay_amt); ?> <span class="badge">-<?php echo e($tds_percent); ?>%</span></td>
                                    <td><?php if($redeem_request->status == 'approved'): ?>
                                            <label class="label label-success">Approved</label>
                                        <?php elseif($redeem_request->status == 'pending'): ?>
                                            <label class="label label-warning">Pending</label>
                                        <?php else: ?>
                                            <label class="label label-danger"
                                                   title="<?php echo e($redeem_request->reject_reason); ?>"
                                                   data-toggle="tooltip" data-placement="top">Rejected</label>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(isset($redeem_request->reject_reason)?$redeem_request->reject_reason:'-'); ?></td>
                                    <td> <?php echo e(isset($redeem_request->approved_time)?date_format(date_create($redeem_request->approved_time), "d-M-Y h:i A"):'-'); ?></td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <br/>
    <script>
        function approved(dis) {
            var id = $(dis).attr('id');
            $('#myModal').modal('show');
            $('#mybody').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/images/loading.gif')); ?>"/>');
            $('#modal_title').html('Confirm Inactivation');
            $('#mybody').html('<h5>Are you sure want to accept this request<h5/>');
            $('#modalBtn').removeClass('hidden');
            $('#modalBtn').html('<a class="btn btn-sm btn-success" href="<?php echo e(url('redeem_request')); ?>/' + id +
                '/approve"><span class="glyphicon glyphicon-ok" aria-hidden="true"></span> Confirm</a>'
            );
        }

        function reject(dis) {
            $('#myModal').modal('show');
            $('#modal_title').html('Reject Redeem Request');
            $('#mybody').html('<img height="50px" class="center-block" src="<?php echo e(url('assets/images/loading.gif')); ?>"/>');
            var id = $(dis).attr('id');
            var editurl = '<?php echo e(url('/')); ?>' + "/redeem_request/" + id + "/reject";
            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url: editurl,
                data: '{"data":"' + id + '"}',
                success: function (data) {
                    $('#mybody').html(data);
                },
                error: function (xhr, status, error) {
                    $('#mybody').html(xhr.responseText);
                    //$('.modal-body').html("Technical Error Occured!");
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>