<?php $__env->startSection('title', 'Franchise Users'); ?>

<?php $__env->startSection('head'); ?>
    <style>

        .btn_center {
            text-align: center;
            margin-top: 10px;
        }

        .update_btn {
            display: none;
        }

        .hidealways {
            display: none;
        }

        .label_checkbox {
            display: inline-block;
        }

        .label_checkbox .cr {
            margin: 0px 5px;
        }

        .newrow {
            background: #1e81cd52 !important;
        }

        .border_none {
            border: none !important;
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="box_containner">
        <div class="container-fluid">
            <div class="row">

                <section id="menu2">
                    <div class="col-sm-12 col-md-12 col-xs-12">
                        <div class="dash_boxcontainner white_boxlist">
                            <div class="upper_basic_heading"><span class="white_dash_head_txt">
                       Users By Franchise
                                    
                                    

                    </span>
                                <section id="user_table" class="table_main_containner">
                                    <form action="<?php echo e(url('search_user_by_franchise')); ?>" method="post"
                                          enctype="multipart/form-data">
                                        <div class="col-sm-12">
                                            <div class="col-sm-3">
                                                <label for="">Franchise</label>
                                                <?php echo Form::select('franchise_id', $franchises, null,['class' => 'form-control requiredDD']); ?>


                                            </div>
                                            <div class="col-sm-3">
                                                <label for="">Start End</label>
                                                <input type="text" placeholder="Start Date"
                                                       data-format="dd/MM/yyyy hh:mm:ss" autocomplete="off"
                                                       class="form-control dtp"
                                                       name="start_date"/>
                                            </div>
                                            <div class="col-sm-3">
                                                <label for="">End Date</label>
                                                <input type="text" placeholder="End Date" class="form-control dtp"
                                                       autocomplete="off" name="end_date"/>
                                            </div>
                                            <br>
                                            <div class="col-sm-3">
                                                <span></span>
                                                <button class="btn btn-primary">Search</button>
                                                <a href="<?php echo e(url('user_by_franchise')); ?>"
                                                   class="btn btn-success">Refresh</a>
                                            </div>
                                        </div>
                                    </form>

                                    <div class="table-scroll style-scroll">
                                        <table id="example" class="table table-bordered dataTable table-striped"
                                               cellspacing="0"
                                               width="100%">
                                            <thead>
                                            <tr class="bg-info">
                                                <th class="hidden">Id</th>
                                                <th>Profile</th>
                                                <th>Referral Code</th>
                                                <th>Name</th>
                                                <th>Contact</th>
                                                <th>Paytm No</th>
                                                <th>Points</th>
                                                <th>Reffer By</th>
                                                <th>Activated By</th>
                                                <th>Joining Date</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php if(count($users)>0): ?>
                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_master): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $user = DB::selectOne("SELECT * FROM users where id in (select reffer_by from reffer where reffer_to = $user_master->id)");
                                                    ?>
                                                    <tr>
                                                        <td class="hidden"><?php echo e($user_master->id); ?></td>

                                                        <td>
                                                            <div class="post_imgblock_admin"><img
                                                                        style="height: 100%; width: 100%"
                                                                        src="<?php echo e(url('').'/'.$user_master->profile_img); ?>"/>
                                                            </div>
                                                        </td>
                                                        <td><?php echo e($user_master->rc); ?></td>
                                                        <td><?php echo e($user_master->name); ?></td>
                                                        <td><?php echo e($user_master->contact); ?></td>
                                                        <td><?php echo e($user_master->paytm_contact); ?></td>
                                                        <td><?php echo e($user_master->points); ?></td>
                                                        <td>
                                                            <?php if(isset($user)): ?>
                                                                <?php echo e($user->name); ?> <br> <?php echo e($user->rc); ?>

                                                            <?php else: ?>
                                                                <?php echo e("-"); ?>

                                                            <?php endif; ?>
                                                        </td>

                                                        <td>

                                                            <p class="bg-success"><?php echo e(isset($user_master->activated_by)?$user_master->activate_by->name:'-'); ?></p>

                                                        </td>
                                                        <td> <?php echo e(date_format(date_create($user_master->created_time), "d-M-Y h:i A")); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </section>
                            </div>


                        </div>
                    </div>
                </section>
            </div>
        </div>
    </section>
    <script>

        // $('.btnDelete').click(function () {
        
        
        
        // $("#loaded_frm").submit();
        // });

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        
        

        function searchTable() {
            var input, filter, found, table, tr, td, i, j;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            table = document.getElementById("myTable");
            tr = table.getElementsByTagName("tr");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td");
                for (j = 0; j < td.length; j++) {
                    if (td[j].innerHTML.toUpperCase().indexOf(filter) > -1) {
                        found = true;
                    }
                }
                if (found) {
                    tr[i].style.display = "";
                    found = false;
                } else {
                    tr[i].style.display = "none";
                }
            }
        }

        function edit_loaded(dis) {
            $('#myModal').modal('show');
            $('#modal_title').html('Edit Loaded Items');
            $('#modal_body').html('<img height="50px" class="center-block" src="<?php echo e(url('images/loading.gif')); ?>"/>');

            var id = $(dis).attr('id');
            var editurl = '<?php echo e(url('/')); ?>' + "/edit_loaded/" + id;
            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url: editurl,
                // data: '{"data":"' + id + '"}',
                data: {id: id},
                success: function (data) {
                    $('#modal_body').html(data);
                },
                error: function (xhr, status, error) {
                    $('#modal_body').html(xhr.responseText);
                    //$('#modal_body').html("Technical Error Occured!");
                }
            });
        }
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>