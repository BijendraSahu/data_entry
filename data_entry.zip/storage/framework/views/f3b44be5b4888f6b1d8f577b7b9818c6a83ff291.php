<?php $__env->startSection('title', 'Amount Distribution'); ?>

<?php $__env->startSection('head'); ?>
    <style>

        .btn_center {
            text-align: center;
            margin-top: 10px;
        }

        .update_btn {
            display: none;
        }

        .hidealways {
            display: none;
        }

        .label_checkbox {
            display: inline-block;
        }

        .label_checkbox .cr {
            margin: 0px 5px;
        }

        .newrow {
            background: #1e81cd52 !important;
        }

        .border_none {
            border: none !important;
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="box_containner">
        <div class="container-fluid">
            <div class="row">

                <section id="menu2">
                    <div class="col-sm-12 col-md-12 col-xs-12">
                        <div class="dash_boxcontainner white_boxlist">
                            <div class="upper_basic_heading"><span class="white_dash_head_txt">
                       Amount Distribution Report
                                    
                                    

                    </span>
                                <section id="user_table" class="table_main_containner">
                                    <form action="<?php echo e(url('distribution')); ?>" method="post"
                                          enctype="multipart/form-data">
                                        <div class="col-sm-12">

                                            <div class="col-sm-4">
                                                <label for="">Start End</label>
                                                <input type="text" placeholder="Start Date"
                                                       data-format="dd/MM/yyyy hh:mm:ss" autocomplete="off"
                                                       class="form-control dtp"
                                                       name="start_date"/>
                                            </div>
                                            <div class="col-sm-4">
                                                <label for="">End Date</label>
                                                <input type="text" placeholder="End Date" class="form-control dtp"
                                                       autocomplete="off" name="end_date"/>
                                            </div>
                                            <br>
                                            <div class="col-sm-4">
                                                <span></span>
                                                <button class="btn btn-primary">Search</button>
                                                <a href="<?php echo e(url('distribution')); ?>" class="btn btn-success">Refresh</a>
                                            </div>
                                        </div>
                                    </form>

                                        <div class="table-scroll style-scroll">
                                            <table id="example" class="table table-bordered dataTable table-striped" cellspacing="0"
                                                   width="100%">
                                                <thead>
                                                <tr class="bg-info">
                                                    <th class="hidden">Id</th>
                                                    <th>Name</th>
                                                    <th>Contact</th>
                                                    <th>Paytm Contact</th>
                                                    <th>Points Request</th>
                                                    <th>Amount</th>
                                                    <th>Status</th>
                                                    <th>Reject Reason</th>
                                                    <th>Approval Date</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php if(count($redeem_requests)>0): ?>
                                                    <?php $__currentLoopData = $redeem_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $redeem_request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td class="hidden"><?php echo e($redeem_request->id); ?></td>

                                                            <td><?php echo e(isset($redeem_request->user->name)?$redeem_request->user->name:"-"); ?></td>
                                                            <td><?php echo e(isset($redeem_request->user->contact)?$redeem_request->user->contact:''); ?></td>
                                                            <td><?php echo e(isset($redeem_request->user->paytm_contact)?$redeem_request->user->paytm_contact:''); ?></td>
                                                            <td><?php echo e($redeem_request->point); ?></td>
                                                            <td><?php echo e("Rs. ".$redeem_request->amount); ?></td>
                                                            <td><?php if($redeem_request->status == 'approved'): ?>
                                                                    <label class="label label-success">Approved</label>
                                                                <?php elseif($redeem_request->status == 'pending'): ?>
                                                                    <label class="label label-warning">Pending</label>
                                                                <?php else: ?>
                                                                    <label class="label label-danger"
                                                                           title="<?php echo e($redeem_request->reject_reason); ?>"
                                                                           data-toggle="tooltip" data-placement="top">Rejected</label>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td><?php echo e(isset($redeem_request->reject_reason)?$redeem_request->reject_reason:'-'); ?></td>
                                                            <td> <?php echo e(isset($redeem_request->approved_time)?date_format(date_create($redeem_request->approved_time), "d-M-Y h:i A"):'-'); ?></td>

                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                </section>
                            </div>


                        </div>
                    </div>
                </section>
            </div>
        </div>
    </section>
    <script>

        // $('.btnDelete').click(function () {
        
        
        
        // $("#loaded_frm").submit();
        // });

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        
        

        function searchTable() {
            var input, filter, found, table, tr, td, i, j;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            table = document.getElementById("myTable");
            tr = table.getElementsByTagName("tr");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td");
                for (j = 0; j < td.length; j++) {
                    if (td[j].innerHTML.toUpperCase().indexOf(filter) > -1) {
                        found = true;
                    }
                }
                if (found) {
                    tr[i].style.display = "";
                    found = false;
                } else {
                    tr[i].style.display = "none";
                }
            }
        }

        function edit_loaded(dis) {
            $('#myModal').modal('show');
            $('#modal_title').html('Edit Loaded Items');
            $('#modal_body').html('<img height="50px" class="center-block" src="<?php echo e(url('images/loading.gif')); ?>"/>');

            var id = $(dis).attr('id');
            var editurl = '<?php echo e(url('/')); ?>' + "/edit_loaded/" + id;
            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url: editurl,
                // data: '{"data":"' + id + '"}',
                data: {id: id},
                success: function (data) {
                    $('#modal_body').html(data);
                },
                error: function (xhr, status, error) {
                    $('#modal_body').html(xhr.responseText);
                    //$('#modal_body').html("Technical Error Occured!");
                }
            });
        }
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>