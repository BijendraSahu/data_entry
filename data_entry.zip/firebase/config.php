<?php

// Firebase API Key
define('FIREBASE_API_KEY', 'AIzaSyCFHhMjw5838GOT0vVKTx9fh99W2Sf5eHI');